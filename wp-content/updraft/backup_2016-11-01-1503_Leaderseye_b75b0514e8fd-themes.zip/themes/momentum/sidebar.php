<div class="sidebar">
	<?php peTheme()->sidebar->show("default",!(is_single() || is_page())); ?>
</div>