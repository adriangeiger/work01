<?php

class PeThemeViewLayoutModuleMomentumContainer extends PeThemeViewLayoutModuleContainer {
	
	public function render() {
		$this->template();
	}
}

?>