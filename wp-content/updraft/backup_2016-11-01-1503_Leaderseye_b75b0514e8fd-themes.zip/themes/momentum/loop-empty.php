<!-- no posts -->
<div class="post-body pe-wp-default">
	<p><?php _e("Your search returned no results. Please try a different keyword or browse using categories & tags",'Pixelentity Theme/Plugin'); ?></p>
</div>
